const CACHE_NAME = 'todo-app-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/service-worker.js',
  '/to-do-list-app/src/index.html',
  '/to-do-list-app/src/style.css',
  '/to-do-list-app/src/script.js',
  '/to-do-list-app/dist/index.html',
  '/to-do-list-app/dist/style.css',
  '/to-do-list-app/dist/script.js',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(k => (k !== CACHE_NAME ? caches.delete(k) : null)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.mode === 'navigate') {
    event.respondWith(caches.match('/index.html').then(res => res || fetch(req)));
    return;
  }
  event.respondWith(
    caches.match(req).then(res => res || fetch(req).then(networkRes => {
      return caches.open(CACHE_NAME).then(cache => {
        try { cache.put(req, networkRes.clone()); } catch(e) { }
        return networkRes;
      });
    }).catch(() => caches.match('/index.html')))
  );
});